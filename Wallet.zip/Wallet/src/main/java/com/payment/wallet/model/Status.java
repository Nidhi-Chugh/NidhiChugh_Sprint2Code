package com.payment.wallet.model;

public enum Status {
	
		ACTIVE, INACTIVE;
	
}
